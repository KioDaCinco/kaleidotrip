function openDemo() {
  alert("Demo: This is a static prototype. Use these files for your GitHub Pages site.");
}

function downloadFiles() {
  alert("You already have all files: index.html, style.css, and script.js. Upload them to GitHub to publish!");
}
